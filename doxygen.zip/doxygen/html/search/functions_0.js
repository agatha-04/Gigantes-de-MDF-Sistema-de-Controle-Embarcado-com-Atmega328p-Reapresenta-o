var searchData=
[
  ['adc_5finit_0',['adc_init',['../car__main__final_8c.html#a2b815e6730e8723a6d1d06d9ef8f31c0',1,'car_main_final.c']]],
  ['adc_5fread_1',['adc_read',['../car__main__final_8c.html#a7c3d687942e3acba4e53cac61d9e71ea',1,'car_main_final.c']]]
];
