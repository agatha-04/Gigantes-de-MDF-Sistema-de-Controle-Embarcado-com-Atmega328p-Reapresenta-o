var indexSectionsWithContent =
{
  0: "abcdefilmprstu",
  1: "c",
  2: "adilmprtu",
  3: "lmrs",
  4: "abdeflmpru"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Arquivos",
  2: "Funções",
  3: "Variáveis",
  4: "Definições e Macros"
};

