var searchData=
[
  ['pause_5fafter_5frotate_5fms_0',['PAUSE_AFTER_ROTATE_MS',['../car__main__final_8c.html#a12550d628f0145388a532b9384988b41',1,'car_main_final.c']]]
];
